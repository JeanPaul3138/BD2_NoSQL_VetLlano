﻿import os
from dotenv import load_dotenv
from pymongo import MongoClient

load_dotenv()
client = MongoClient(os.getenv("MONGO_URI"))
db = client[os.getenv("DB_NAME")]
servicios = db["servicios"]

servicios.delete_many({"codigo": "SRV-099"})

print("--- CONEXION EXITOSA A VETLLANO_DB ---")

nuevo = {
    "codigo": "SRV-099",
    "nombre": "Teleconsulta Veterinaria de Control",
    "categoria": "Consulta",
    "precio_cop": 35000,
    "duracion_minutos": 20,
    "especies_aplicables": ["Canino", "Felino"],
    "requiere_ayuno": False
}
ins = servicios.insert_one(nuevo)
print(f"\n[CREATE] Servicio insertado con ID: {ins.inserted_id}")

enc = servicios.find_one({"codigo": "SRV-099"}, {"_id": 0})
print(f"[READ] Servicio encontrado: {enc}")

upd = servicios.update_one({"codigo": "SRV-099"}, {"$set": {"precio_cop": 42000}})
act = servicios.find_one({"codigo": "SRV-099"}, {"_id": 0, "nombre": 1, "precio_cop": 1})
print(f"[UPDATE] Modificados: {upd.modified_count} -> {act}")

dele = servicios.delete_one({"codigo": "SRV-099"})
print(f"[DELETE] Eliminados: {dele.deleted_count}")

client.close()
