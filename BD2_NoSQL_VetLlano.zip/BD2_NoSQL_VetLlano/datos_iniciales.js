// ============================================================================
// PROYECTO: VetLlano - Sistema de Gestión Veterinaria (Villavicencio, Meta)
// SCRIPT: datos_iniciales.js (Versión compacta: esquema, validación y 60 docs)
// ============================================================================

db = db.getSiblingDB("vetllano_db");

["propietarios", "mascotas", "consultas", "servicios"].forEach(c => db[c].drop());

// 1. Colección con validación $jsonSchema (campos obligatorios, tipos, enum y rangos)
db.createCollection("mascotas", {
  validator: {
    $jsonSchema: {
      bsonType: "object",
      required: ["propietario_id", "nombre", "especie", "sexo", "peso_kg", "vacunas"],
      properties: {
        propietario_id: { bsonType: "objectId" },
        nombre: { bsonType: "string" },
        especie: { enum: ["Canino", "Felino", "Ave", "Roedor"] },
        sexo: { enum: ["M", "H"] },
        peso_kg: { bsonType: ["double", "int"], minimum: 0.05, maximum: 120.0 },
        vacunas: {
          bsonType: "array",
          items: {
            bsonType: "object",
            required: ["nombre_vacuna", "fecha_aplicacion", "lote"],
            properties: {
              nombre_vacuna: { bsonType: "string" },
              fecha_aplicacion: { bsonType: "date" },
              proxima_dosis: { bsonType: "date" },
              lote: { bsonType: "string" }
            }
          }
        }
      }
    }
  }
});

// 2. Arreglos base del contexto regional (Villavicencio)
const barrios = ["La Esperanza", "Barzal Alto", "Amarilo", "Buque", "Porfía", "Caudal", "Villacentro", "Alborada", "Rosa Blanca", "San Benito", "Gramalote", "Kirpas", "Maracos", "Guatapé", "Siete de Agosto"];
const nombresProp = ["Carlos Mejía", "Laura Gómez", "Jorge Pardo", "María Rojas", "Sandra Ortíz", "Diego Torres", "Paula Castañeda", "Héctor Villalobos", "Camila Beltrán", "Sebastián Ruiz", "Gloria Díaz", "Andrés Morales", "Natalia Vargas", "Óscar Rey", "Juliana Pinzón"];
const mascotasData = [
  ["Toby", "Canino", "Pinscher", "M", 4.2], ["Luna", "Canino", "Pinscher", "H", 4.8], ["Michi", "Felino", "Criollo", "M", 5.1],
  ["Max", "Canino", "Labrador", "M", 31.5], ["Nala", "Felino", "Siamés", "H", 3.9], ["Bruno", "Canino", "Bull Terrier", "M", 24.0],
  ["Kira", "Canino", "Husky", "H", 21.8], ["Paco", "Ave", "Perico", "M", 0.08], ["Thor", "Canino", "Pastor Alemán", "M", 36.4],
  ["Milo", "Felino", "Persa", "M", 4.5], ["Canela", "Canino", "Criollo", "H", 16.2], ["Copito", "Roedor", "Conejo", "M", 1.4],
  ["Zeus", "Canino", "Rottweiler", "M", 42.0], ["Maya", "Canino", "Poodle", "H", 6.3], ["Simba", "Felino", "Criollo", "M", 4.1]
];
const diagnosticos = ["Gastroenteritis leve", "Control post-operatorio", "Cistitis felina", "Distensión muscular", "Rinitis alérgica", "Dermatitis por pulgas", "Limpieza dental", "Corte de pico", "Otitis externa", "Bolas de pelo", "Desparasitación", "Estasis digestiva", "Laceración plantar", "Control alergia", "Chequeo general"];
const serviciosNombres = ["Consulta General", "Consulta Control", "Consulta Exóticos", "Vacuna Pentavalente", "Vacuna Triple Felina", "Vacuna Antirrábica", "Esterilización Felina", "Esterilización Canina", "Profilaxis Dental", "Cuadro Hemático", "Perfil Renal", "Coprológico", "Baño Medicado", "Peluquería Canina", "Ecografía Abdominal"];

// 3. Generación e inserción de 15 documentos por colección (60 en total)
const propietarios = [], mascotas = [], consultas = [], servicios = [];

for (let i = 0; i < 15; i++) {
  const propId = new ObjectId();
  const mascId = new ObjectId();

  propietarios.push({
    _id: propId,
    cedula: `112189${1000 + i}`,
    nombre_completo: nombresProp[i],
    telefono: `3104589${100 + i}`,
    email: `cliente${i + 1}@vetllano.com`,
    direccion: { barrio: barrios[i], ciudad: "Villavicencio", departamento: "Meta" },
    activo: i !== 11
  });

  mascotas.push({
    _id: mascId,
    propietario_id: propId, // Referencia
    nombre: mascotasData[i][0],
    especie: mascotasData[i][1],
    raza: mascotasData[i][2],
    sexo: mascotasData[i][3],
    peso_kg: mascotasData[i][4],
    esterilizado: i % 2 === 0,
    alergias: i % 3 === 0 ? ["Pollo", "Dipirona"] : [],
    vacunas: [ // Subdocumentos embebidos
      { nombre_vacuna: i % 2 === 0 ? "Pentavalente" : "Triple Felina", fecha_aplicacion: new Date(`2026-0${(i % 8) + 1}-10`), proxima_dosis: new Date(`2027-0${(i % 8) + 1}-10`), lote: `VAC-2026-${100 + i}` },
      { nombre_vacuna: "Antirrábica", fecha_aplicacion: new Date("2026-03-15"), proxima_dosis: new Date("2027-03-15"), lote: `RAB-2026-${200 + i}` }
    ]
  });

  consultas.push({
    mascota_id: mascId, // Referencia
    propietario_id: propId, // Referencia
    fecha_consulta: new Date(`2026-10-${String(i + 1).padStart(2, "0")}`),
    veterinario: i % 2 === 0 ? "Dra. Laura Gómez" : "Dr. Julián Rojas",
    motivo: `Motivo clínico #${i + 1}`,
    signos_vitales: { peso_kg: mascotasData[i][4], temperatura_c: 38.6, frecuencia_cardiaca: 120 + i }, // Embebido
    diagnostico: diagnosticos[i],
    medicamentos_recetados: [{ nombre: "Omeprazol 10mg", dosis: "1/2 tab", dias: 5 }], // Embebido
    costo_consulta: 45000 + (i * 5000),
    estado_pago: i % 4 === 0 ? "Pendiente" : "Pagado"
  });

  servicios.push({
    codigo: `SRV-${String(i + 1).padStart(3, "0")}`,
    nombre: serviciosNombres[i],
    categoria: i < 3 ? "Consulta" : i < 6 ? "Vacunación" : i < 9 ? "Cirugía" : "Laboratorio",
    precio_cop: 40000 + (i * 10000),
    duracion_minutos: 30,
    especies_aplicables: i % 2 === 0 ? ["Canino", "Felino"] : ["Canino"],
    requiere_ayuno: i >= 6 && i <= 10
  });
}

db.propietarios.insertMany(propietarios);
db.mascotas.insertMany(mascotas);
db.consultas.insertMany(consultas);
db.servicios.insertMany(servicios);

print("Listo: 4 colecciones creadas y 60 documentos insertados (15 por colección).");