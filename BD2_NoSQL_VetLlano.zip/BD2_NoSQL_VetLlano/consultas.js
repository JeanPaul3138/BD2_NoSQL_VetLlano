// ============================================================================
// PROYECTO: VetLlano - Sistema de Gestión Veterinaria
// SCRIPT: consultas.js (10 Consultas, 4 Actualizaciones, 3 Agregaciones, 3 Índices)
// ============================================================================

db = db.getSiblingDB("vetllano_db");

print("=== 1. LAS 10 CONSULTAS DEL NEGOCIO ===");

// Q1: ¿Qué perros pesan más de 20 kg? (Operador de comparación $gt y ordenamiento)
printjson(db.mascotas.find({ especie: "Canino", peso_kg: { $gt: 20 } }, { nombre: 1, raza: 1, peso_kg: 1, _id: 0 }).sort({ peso_kg: -1 }).toArray());

// Q2: ¿Qué mascotas son Caninos o Felinos y están esterilizadas? (Operador lógico $and / $in y proyección)
printjson(db.mascotas.find({ especie: { $in: ["Canino", "Felino"] }, esterilizado: true }, { nombre: 1, especie: 1, raza: 1, _id: 0 }).toArray());

// Q3: ¿Qué propietarios activos viven en los barrios 'La Esperanza' o 'Buque'? (Búsqueda en subdocumento)
printjson(db.propietarios.find({ activo: true, "direccion.barrio": { $in: ["La Esperanza", "Buque"] } }, { nombre_completo: 1, telefono: 1, "direccion.barrio": 1, _id: 0 }).toArray());

// Q4: ¿Qué mascotas son alérgicas al 'Pollo'? (Búsqueda en arreglo simple)
printjson(db.mascotas.find({ alergias: "Pollo" }, { nombre: 1, especie: 1, alergias: 1, _id: 0 }).toArray());

// Q5: ¿Qué mascotas recibieron la vacuna 'Pentavalente'? (Búsqueda en arreglo de subdocumentos)
printjson(db.mascotas.find({ "vacunas.nombre_vacuna": "Pentavalente" }, { nombre: 1, "vacunas.$": 1, _id: 0 }).toArray());

// Q6: ¿Qué consultas están pendientes de pago y cuestan $60.000 o más? (Operadores $gte y lógico implícito)
printjson(db.consultas.find({ estado_pago: "Pendiente", costo_consulta: { $gte: 60000 } }, { fecha_consulta: 1, veterinario: 1, costo_consulta: 1, _id: 0 }).toArray());

// Q7: ¿Qué pacientes presentaron temperatura superior a 39.0°C en consulta? (Subdocumento signos_vitales)
printjson(db.consultas.find({ "signos_vitales.temperatura_c": { $gt: 39.0 } }, { motivo: 1, diagnostico: 1, "signos_vitales.temperatura_c": 1, _id: 0 }).toArray());

// Q8: ¿Qué servicios de Cirugía o Laboratorio requieren ayuno previo? (Operador lógico $or)
printjson(db.servicios.find({ $or: [{ categoria: "Cirugía" }, { categoria: "Laboratorio" }], requiere_ayuno: true }, { codigo: 1, nombre: 1, precio_cop: 1, _id: 0 }).sort({ precio_cop: 1 }).toArray());

// Q9: ¿Cuáles son los 5 servicios más económicos disponibles para Felinos? (Arreglo + ordenamiento + limit)
printjson(db.servicios.find({ especies_aplicables: "Felino" }, { nombre: 1, precio_cop: 1, _id: 0 }).sort({ precio_cop: 1 }).limit(5).toArray());

// Q10: ¿Qué consultas fueron atendidas por la 'Dra. Laura Gómez' en octubre de 2026? (Rango de fechas)
printjson(db.consultas.find({ veterinario: "Dra. Laura Gómez", fecha_consulta: { $gte: new Date("2026-10-01"), $lte: new Date("2026-10-31") } }, { fecha_consulta: 1, diagnostico: 1, costo_consulta: 1, _id: 0 }).toArray());


print("=== 2. LAS 4 OPERACIONES DE ACTUALIZACIÓN ===");

// U1 ($set): Marcar como 'Pagado' una consulta pendiente del Dr. Julián Rojas
printjson(db.consultas.updateOne({ estado_pago: "Pendiente", veterinario: "Dr. Julián Rojas" }, { $set: { estado_pago: "Pagado" } }));

// U2 ($inc): Aplicar un incremento de $5.000 COP a todos los servicios de categoría 'Consulta'
printjson(db.servicios.updateMany({ categoria: "Consulta" }, { $inc: { precio_cop: 5000 } }));

// U3 ($push y $pull): Agregar una nueva vacuna al carné de 'Toby' y eliminar la alergia 'Dipirona'
printjson(db.mascotas.updateOne({ nombre: "Toby" }, {
  $push: { vacunas: { nombre_vacuna: "Tos de las Perreras", fecha_aplicacion: new Date("2026-11-12"), proxima_dosis: new Date("2027-11-12"), lote: "TOS-2026-999" } },
  $pull: { alergias: "Dipirona" }
}));

// U4 (upsert): Actualizar precio del servicio 'SRV-016' o crearlo si no existe en el catálogo
printjson(db.servicios.updateOne(
  { codigo: "SRV-016" },
  { $set: { nombre: "Microchip de Identificación", categoria: "Laboratorio", precio_cop: 90000, duracion_minutos: 15, especies_aplicables: ["Canino", "Felino"], requiere_ayuno: false } },
  { upsert: true }
));


print("=== 3. LAS 3 AGREGACIONES DE NEGOCIO ===");

// A1 ($lookup): Reporte de consultas mostrando el nombre de la mascota y el teléfono del dueño
printjson(db.consultas.aggregate([
  { $lookup: { from: "mascotas", localField: "mascota_id", foreignField: "_id", as: "info_mascota" } },
  { $lookup: { from: "propietarios", localField: "propietario_id", foreignField: "_id", as: "info_dueno" } },
  { $unwind: "$info_mascota" },
  { $unwind: "$info_dueno" },
  { $project: { _id: 0, fecha: "$fecha_consulta", mascota: "$info_mascota.nombre", dueno: "$info_dueno.nombre_completo", telefono: "$info_dueno.telefono", diagnostico: 1, costo_consulta: 1 } },
  { $limit: 5 }
]).toArray());

// A2 ($unwind + $group): Conteo total de dosis aplicadas por tipo de vacuna en la clínica
printjson(db.mascotas.aggregate([
  { $unwind: "$vacunas" },
  { $group: { _id: "$vacunas.nombre_vacuna", total_aplicadas: { $sum: 1 } } },
  { $sort: { total_aplicadas: -1 } }
]).toArray());

// A3 ($group): Ingresos totales, promedio por consulta y cantidad de atenciones por veterinario
printjson(db.consultas.aggregate([
  { $group: { _id: "$veterinario", total_atenciones: { $sum: 1 }, ingresos_cop: { $sum: "$costo_consulta" }, ticket_promedio: { $avg: "$costo_consulta" } } }
]).toArray());


print("=== 4. ÍNDICES Y COMPARACIÓN DE RENDIMIENTO (EXPLAIN) ===");

// Limpiar índices personalizados previos (si existen) para medir el ANTES real
db.propietarios.dropIndexes();
db.mascotas.dropIndexes();
db.consultas.dropIndexes();

// --- Índice 1: Único en propietarios.cedula ---
print("ANTES Índice 1 (Búsqueda por cédula - COLLSCAN):");
const antes1 = db.propietarios.find({ cedula: "1121891005" }).explain("executionStats");
print("Stage:", antes1.executionStats.executionStages.stage, "| Docs examinados:", antes1.executionStats.totalDocsExamined);

db.propietarios.createIndex({ cedula: 1 }, { unique: true });

print("DESPUÉS Índice 1 (Búsqueda por cédula - IXSCAN):");
const despues1 = db.propietarios.find({ cedula: "1121891005" }).explain("executionStats");
print("Stage:", despues1.executionStats.executionStages.stage, "| Docs examinados:", despues1.executionStats.totalDocsExamined);

// --- Índice 2: Compuesto en mascotas (especie + peso_kg) ---
print("ANTES Índice 2 (Filtro especie + peso - COLLSCAN):");
const antes2 = db.mascotas.find({ especie: "Canino", peso_kg: { $gt: 20 } }).explain("executionStats");
print("Stage:", antes2.executionStats.executionStages.stage, "| Docs examinados:", antes2.executionStats.totalDocsExamined);

db.mascotas.createIndex({ especie: 1, peso_kg: -1 });

print("DESPUÉS Índice 2 (Filtro especie + peso - IXSCAN):");
const despues2 = db.mascotas.find({ especie: "Canino", peso_kg: { $gt: 20 } }).explain("executionStats");
print("Stage:", despues2.executionStats.executionStages.stage, "| Docs examinados:", despues2.executionStats.totalDocsExamined);

// --- Índice 3: Simple en consultas.propietario_id (para acelerar $lookup) ---
db.consultas.createIndex({ propietario_id: 1 });
print("Índice 3 creado en consultas.propietario_id para optimizar cruces ($lookup).");